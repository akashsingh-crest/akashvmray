import { LogLevel, PublicClientApplication } from "@azure/msal-browser";
import { forwardMailToMiddleTier } from "./middle-tier-calls";

const loginRequest = {
  scopes: []
};

async function loadConfig() {
  return new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = "/runtime-config.js";
    script.onload = () => resolve(window.APP_CONFIG);
    script.onerror = reject;
    document.head.appendChild(script);
  });
}

let publicClientApp = null;
let loginDialog = null;
let homeAccountId = null;
let callbackFunction = null;
let storedMessageId = null;
let tokenAcquiredHandler = null;
let authRequestCompleted = false;

function finishAuth(result) {
  if (authRequestCompleted) {
    return;
  }
  authRequestCompleted = true;
  callbackFunction?.(result);
}

async function initializeMsal() {
  const cfg = await loadConfig();

  const clientId = cfg.clientId;
  const tenantId = cfg.tenantId;
  const domain = cfg.domain;

  const accessScope = `api://${domain}/${clientId}/access_as_user`;

  loginRequest.scopes = [accessScope];

  const msalConfig = {
    auth: {
      clientId: clientId,
      authority: `https://login.microsoftonline.com/${tenantId}`,
      redirectUri: `https://${domain}/fallbackauthdialog.html`,
      navigateToLoginRequestUrl: false
    },
    cache: {
      cacheLocation: "sessionStorage",
      storeAuthStateInCookie: true
    },
    system: {
      loggerOptions: {
        loggerCallback: (level, message, containsPii) => {
          if (containsPii) return;

          switch (level) {
            case LogLevel.Error:
              console.error(message);
              break;
            case LogLevel.Info:
              console.info(message);
              break;
            case LogLevel.Verbose:
              console.debug(message);
              break;
            case LogLevel.Warning:
              console.warn(message);
              break;
          }
        }
      }
    }
  };

  publicClientApp = new PublicClientApplication(msalConfig);
}

Office.onReady(async () => {
   try {
    await initializeMsal();
  } catch (err) {
    console.error("MSAL initialization failed:", err);

    if (Office.context.ui.messageParent) {
      Office.context.ui.messageParent(
        JSON.stringify({
          status: "failure",
          result: { errorMessage: "Authentication setup failed." }
        })
      );
    }
    return;
  }
  

  if (Office.context.ui.messageParent) {
    let redirectResponse = null;

    try {
      redirectResponse = await publicClientApp.handleRedirectPromise();
    } catch (error) {
      console.log(error);
      Office.context.ui.messageParent(
        JSON.stringify({ status: "failure", result: error })
      );
      return;
    }

    if (redirectResponse) {
      await handleResponse(redirectResponse);
      return;
    }

    try {
      if (localStorage.getItem("loggedIn") === "yes") {
        await publicClientApp.acquireTokenRedirect(loginRequest);
      } else {
        await publicClientApp.loginRedirect(loginRequest);
      }
    } catch (error) {
      console.error("Redirect start failed:", error);
      Office.context.ui.messageParent(
        JSON.stringify({
          status: "failure",
          result: { errorMessage: "Authentication redirect failed." }
        })
      );
    }
  }
});

async function handleResponse(response) {
  if (!response) return;

  if (response.tokenType === "id_token") {
    console.log("LoggedIn");
    localStorage.setItem("loggedIn", "yes");

    try {
      await publicClientApp.acquireTokenRedirect(loginRequest);
    } catch (error) {
      console.error("Acquire token redirect failed:", error);
      Office.context.ui.messageParent(
        JSON.stringify({
          status: "failure",
          result: { errorMessage: "Authentication token redirect failed." }
        })
      );
    }
    return;
  }

  console.log("token type is:" + response.tokenType);
  Office.context.ui.messageParent(
    JSON.stringify({
      status: "success",
      result: response.accessToken,
      accountId: response.account?.homeAccountId ?? null,
    })
  );
}

export async function dialogFallback(callback, messageId, onTokenAcquired) {
  storedMessageId = messageId;
  callbackFunction = callback;
  tokenAcquiredHandler = onTokenAcquired;
  authRequestCompleted = false;

  if (!publicClientApp) {
    finishAuth({
      forward: {
        success: false,
        error: "Authentication client is not initialized. Please try again."
      }
    });
    return;
  }

  if (homeAccountId !== null) {
    try {
      const result = await publicClientApp.acquireTokenSilent({
        ...loginRequest,
        account: publicClientApp.getAccountByHomeId(homeAccountId)
      });

      if (result && result.accessToken) {
        if (tokenAcquiredHandler) {
          tokenAcquiredHandler();
        }

        const response = await forwardMailToMiddleTier(result.accessToken, messageId);
        finishAuth(response);
        return;
      }
    } catch (silentError) {
      console.warn("Silent token failed. Falling back to dialog.", silentError);
    }
  }

  showLoginPopup("/fallbackauthdialog.html");
}

async function processMessage(arg) {
  let messageFromDialog;

  try {
    messageFromDialog = JSON.parse(arg.message);
  } catch (e) {
    console.error("Invalid dialog message:", arg.message);

    if (loginDialog) {
      try {
        loginDialog.close();
      } catch {}
      loginDialog = null;
    }

    finishAuth({
      forward: {
        success: false,
        error: "Invalid response received from authentication window."
      }
    });
    return;
  }

  if (messageFromDialog.status === "success") {
    if (loginDialog) {
      try {
        loginDialog.close();
      } catch {}
      loginDialog = null;
    }

    const homeAccount = messageFromDialog.accountId
      ? publicClientApp.getAccountByHomeId(messageFromDialog.accountId)
      : null;
    if (homeAccount) {
      homeAccountId = messageFromDialog.accountId;
      publicClientApp.setActiveAccount(homeAccount);
    }

    if (tokenAcquiredHandler) {
      tokenAcquiredHandler();
    }

    const response = await forwardMailToMiddleTier(messageFromDialog.result, storedMessageId);
    finishAuth(response);
  } else {
    if (loginDialog) {
      try {
        loginDialog.close();
      } catch {}
      loginDialog = null;
    }

    finishAuth({
      forward: {
        success: false,
        error: "Authentication was cancelled. Please try again."
      }
    });

    if (messageFromDialog.error) {
      console.error(JSON.stringify(messageFromDialog.error.toString()));
    } else if (messageFromDialog.result?.errorMessage) {
      console.error(JSON.stringify(messageFromDialog.result.errorMessage.toString()));
    }
  }
}

function handleDialogEvent(arg) {
  console.warn("Dialog event received:", arg);

  if (!loginDialog) {
    return;
  }

  try {
    loginDialog.close();
  } catch (e) {
    console.warn("Dialog close failed or already closed:", e);
  }

  loginDialog = null;

  finishAuth({
    forward: {
      success: false,
      error: "Authentication window was closed, blocked, or failed to load."
    }
  });
}

function showLoginPopup(url) {
  const fullUrl =
    location.protocol + "//" + location.hostname + (location.port ? ":" + location.port : "") + url;

  Office.context.ui.displayDialogAsync(
    fullUrl,
    { height: 60, width: 30 },
    function (result) {
      if (result.status !== Office.AsyncResultStatus.Succeeded) {
        console.error("displayDialogAsync failed:", result.error);

        finishAuth({
          forward: {
            success: false,
            error: "Popup permission was denied or blocked. Please allow the popup and try again."
          }
        });
        return;
      }

      console.log("Dialog initialized successfully");
      loginDialog = result.value;

      loginDialog.addEventHandler(
        Office.EventType.DialogMessageReceived,
        processMessage
      );

      loginDialog.addEventHandler(
        Office.EventType.DialogEventReceived,
        handleDialogEvent
      );
    }
  );
}